<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">

    <title>Panda Express Chinese Restaurant</title>

	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta content='width=device-width, height=device-height' name='viewport'>
    <meta name="description">
    <meta name="keywords">

    <link rel="canonical" href="https://www.pandaexpress.com/Error/NotFound" />

    <!--[if lt IE 9]>
	<script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/respond.js/1.3.0/respond.js"></script>
	<script>window.IS_IE8 = true;</script>
	<link rel="stylesheet" href="/Content/styles/ie.min.css">
	<![endif]-->

	<!--[if IE 9]>
	<script>window.IS_IE9 = true;</script>
	<![endif]-->

	<!--[if (gte IE 9) | (IEMobile)]><!-->
	<link href="/Content/site/frontend-css?v=C4aOCUaSMq39OXjzRv53a9ugRzO49mZxUJhj4x5CCaA1" rel="stylesheet"/>

    <!--<![endif]-->
    <link href="/Content/qaptcha/QapTcha.jquery.css" rel="stylesheet"/>


    <link href="//cdnjs.cloudflare.com/ajax/libs/Swiper/3.4.1/css/swiper.min.css" rel="stylesheet"/>

    <script>
        dataLayer = [];
    </script>
</head>
<body>
    <!-- Google Tag Manager -->
<noscript>
    <iframe src="//www.googletagmanager.com/ns.html?id=GTM-KR93L6" height="0" width="0" style="display:none;visibility:hidden"></iframe>
</noscript>
<script>
        (function (w, d, s, l, i) {
            w[l] = w[l] || []; w[l].push(
            { 'gtm.start': new Date().getTime(), event: 'gtm.js' }
            ); var f = d.getElementsByTagName(s)[0],
            j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : ''; j.async = true; j.src =
            '//www.googletagmanager.com/gtm.js?id=' + i + dl; f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-KR93L6');
</script>
<!-- End Google Tag Manager -->
    <!--  Quantcast Tag -->
<script>
        var ezt = ezt ||[];

        (function(){
            var elem = document.createElement('script');
            elem.src = (document.location.protocol == "https:" ? "https://secure" : "http://pixel") + ".quantserve.com/aquant.js?a=p-Y8YJaDWqbZrNU";
            elem.async = true;
            elem.type = "text/javascript";
            var scpt = document.getElementsByTagName('script')[0];
            scpt.parentNode.insertBefore(elem,scpt);
        }());


        ezt.push({qacct: 'p-Y8YJaDWqbZrNU',
            orderid: '',
            revenue: ''
        });
</script>
<noscript>
    <img src="//pixel.quantserve.com/pixel/p-Y8YJaDWqbZrNU.gif?labels=_fp.event.Default" style="display: none;" border="0" height="1" width="1" alt="Quantcast" />
</noscript>
<!-- End Quantcast Tag -->
    <script type="text/javascript" src="https://10399715.collect.igodigital.com/collect.js"></script>
<script type="text/javascript">
        _etmc.push(["setOrgId", "10399715"]);
        _etmc.push(["trackPageView"]);
</script>
<div id="fb-root"></div>
<script>
// Facebook SDK
(function(d, s, id) { var js, fjs = d.getElementsByTagName(s)[0]; if (d.getElementById(id)) return; js = d.createElement(s); js.id = id; js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.3"; fjs.parentNode.insertBefore(js, fjs); }(document, 'script', 'facebook-jssdk'));
// Twitter
window.twttr=(function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],t=window.twttr||{};if(d.getElementById(id))return t;js=d.createElement(s);js.id=id;js.src="https://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);t._e=[];t.ready=function(f){t._e.push(f);};return t;}(document,"script","twitter-wjs"));
</script>

<div class="wrapper">
	    <div class="top-frame"></div>
        <div id="loading" data-bind="visible: $root.IsLoading"></div>
        <a href="#skip-to-content" class="skip-navigation-button" data-skip-to-content id="skip-to-top">Skip to Content</a>
        <a href="/sitemap" class="skip-navigation-button">Skip to Sitemap</a>
		<!-- Main Navigation -->
<nav class="main-nav" data-mobile-active="false" aria-label="Main Navigation">
    <a class="logo" href="/" aria-label="Panda Express Logo, Click to go home."></a>

    <div class="main-links">
        <div class="link-block submenu-link food" data-a11y-focus>
            <a class="anchor" data-ga-event-menu="Food" href="/menu" data-mobile-label="Food" data-label="Our Food" aria-label="Our Food"><span class="nav-icon"></span></a>
            <div class="submenu">
                <div class="container">
                    <a href="/how-to-order" class="image-link">		                    <img src="https://s3.amazonaws.com/PandaExpressWebsite/img/favorites/fav-menu.jpg" alt="Panda Favorites">		                    <span class="text">Panda Favorites</span>	                    </a><a href="/menu/entrees" class="image-link">		                    <img class="img" src="https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/food/navigation/entrees.jpg" alt="Entrees">		                    <span class="text">Entrees</span>	                    </a>	                    <a href="/menu/sides" class="image-link">		                    <img src="https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/food/navigation/sidedishes.jpg" alt="Sides">		                    <span class="text">Sides</span>	                    </a>	                    <a href="/menu/appetizers" class="image-link">		                    <img src="https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/food/navigation/appetizers.jpg" alt="Appetizers">		                    <span class="text">Appetizers</span>	                    </a>	                   	                    <div class="link-list"><a href="/how-to-order?tab=2">How to Panda</a>&nbsp;<a href="/menu/desserts">Desserts</a>&nbsp;<a href="/Catering">Catering</a>&nbsp;<a href="/wok-smart">Wok Smart</a>&nbsp;<a href="/innovationkitchen">Innovation Kitchen</a>&nbsp;<a href="/teabar">Tea Bar</a>&nbsp;<a href="/pandasfuture">Taste the Future</a>&nbsp;<a href="/masters-of-flavor">Masters of Flavor</a><a href="/wok">Masters of the Wok</a>&nbsp;<a href="https://s3.amazonaws.com/PandaExpressWebsite/files/pdf/Nutrition.pdf" target="_blank">Download Nutrition PDF</a></div>
                </div>
            </div>
        </div>

        <div class="link-block locations" data-a11y-focus>
            <a class="anchor" data-ga-event-menu="Locations" href="/userlocation" data-mobile-label="Locations" data-label="Our Locations" aria-label="Our Locations"><span class="nav-icon"></span></a>
        </div>

        <div class="link-block submenu-link family" data-a11y-focus>
            <a class="anchor" data-ga-event-menu="Our Family Story" href="/ourfamilystory" data-label="Our Family Story" aria-label="Our Family Story"><span class="nav-icon"></span></a>
                <div class="submenu">
                    <div class="container">
                        <a href="/ourfamilystory" class="image-link">                                  <img class="img" src="https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/our-family-story/navigation/Timeline.jpg" alt="Panda Express location">		                    <span class="text">Timeline</span></a><a href="/asian-pacific-american-heritage-month" class="image-link">                                  <img class="img" src="https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/our-family-story/navigation/apahm-thumb.jpg" alt="Inspired kids">		                    <span class="text">Inspire Originality</span></a><a href="http://www.pandacareers.com" class="image-link">                                  <img class="img" src="https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/our-family-story/navigation/Careers.jpg" alt="Employees">		                    <span class="text">Careers</span></a><a href="http://www.pandacares.org" class="image-link">                                  <img class="img" src="https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/our-family-story/navigation/Panda-Cares.jpg" alt="Panda Cares panda with child">		                    <span class="text">Panda Cares</span></a><div class="link-list"><a href="/ourfamilystory/about">About Us</a>&nbsp;<a href="http://www.pandarg.com">Panda Restaurant Group, Inc.</a>&nbsp;<a href="/american-chinese/#1">American Chinese</a>&nbsp;</div>
                    </div>
                </div>
        </div>

        <div class="link-block order" data-a11y-focus>
            <a class="anchor" target="_blank" href="https://orders.pandaexpress.com" data-mobile-label="Order"aria-label="Order Now"><span class="nav-icon"></span></a>
        </div>

        <div class="link-block burger-icon" data-a11y-focus data-mobile-menu-toggle>
            <span class="nav-icon"></span>
        </div>
    </div>

    <ul class="mobile-nav"><!--   <li><a class="mobile-link" data-ga-event-menu="ourfamilystory" href="/ourfamilystory">Our Family Story</a></li>-->        <li>            <button class="submenu-link" data-active="false" data-mobile-sublink="">Our Family Story</button>            <div class="submenu">                <button class="mobile-back" data-mobile-back="">Our Family Story</button>                <a class="mobile-link" href="/ourfamilystory">Timeline</a>         <a class="mobile-link" href="/american-chinese/#1">American Chinese</a>       <a class="mobile-link" href="/ourfamilystory/about">About Us</a>                            <a class="mobile-link" href="http://www.pandacareers.com">Careers</a> <a class="mobile-link" href="http://www.pandacares.org">Panda Cares</a>             <a class="mobile-link" href="http://www.pandarg.com">Panda Restaurant Group, Inc.</a>           </div>        </li><li>            <button class="submenu-link" data-active="false" data-mobile-sublink="">Fundraising</button>            <div class="submenu">                <button class="mobile-back" data-mobile-back="">Fundraising</button>                <a class="mobile-link" href="/fundraiser-landing">Learn More</a>                <a class="mobile-link" href="/fundraiserlogin">Login/Register</a>                <a class="mobile-link" href="/pandafundraisermember">My Account</a>                <a class="mobile-link" href="/fundraiserlogin/FAQ">Frequently Asked Questions</a>                <a class="mobile-link" href="/fundraiserlogin/helpfulfundraisingtips">Helpful Fundraising Tips</a>            </div>        </li>        <li><a class="mobile-link" data-ga-event-menu="Wok Smart" href="/wok-smart">Wok Smart</a></li>        <li><a class="mobile-link" data-ga-event-menu="Masters Of The Wok" href="/wok">Masters Of The Wok</a></li>        <li><a class="mobile-link" data-ga-event-menu="Connect" href="/connectus">Connect With Us</a></li>        <li><a class="mobile-link" data-ga-event-menu="Contact" href="/contactus">Contact Panda</a></li>        <li><a class="mobile-link" data-ga-event-menu="Company" href="http://www.pandarg.com">Company</a></li>        <li><a class="mobile-link" data-ga-event-menu="Gift Cards" href="/giftcards">Gift Cards</a></li>        <li><a class="mobile-link" data-ga-event-menu="Site Map" href="/sitemap">Site Map</a></li>        <li><a class="mobile-link" href="/legal#privacypolicy">Privacy Policy</a></li>        <li><a class="mobile-link" href="/legal#legalstatement">Legal Statement</a></li>        <li><a class="mobile-link" href="/legal#casupplychainact">CA Supply Chain Act</a></li>        <li><a class="mobile-link" href="/accessibility">Accessibility Statement</a></li>        <!--        <li>            <button class="submenu-link" data-active="false" data-mobile-sublink>Legal Statement</button>            <div class="submenu">                <button class="mobile-back" data-mobile-back>Legal Statement</button>                <a class="mobile-link" href="/legal#privacypolicy">Privacy Policy</a>                <a class="mobile-link" href="/legal#legalstatement">Legal Statement</a>                <a class="mobile-link" href="/legal#casupplychainact">CA Supply Chain Act</a>            </div>        </li>        -->    </ul>

    <!-- Nearest Panda -->
    <div class="nearest-panda submenu-link" data-a11y-focus>
        <div class="info-container">
            <button class="order-now-button" data-order-now-button>Order Now</button>
            <div class="info">
                <span class="title">Your Nearest Panda:</span>
                <span class="current-panda"></span>
            </div>
        </div>

        <div class="submenu">
            <div class="container">
                <div class="map-area">
                    <span class="title"><span class="title-icon"></span><span class="title-text">Nearest Panda Express</span><span class="title-miles">?</span></span>
                    <div class="map-container">
                        <img class="static-map" src="" alt="">
                        <div class="location-card">
                            <!-- Card Info gets Put here -->
                        </div>
                    </div>
                    <form class="nav-location-search">
                        <input class="search" type="text" name="location-query" placeholder="Find another Panda by Zip Code, or by City, State" aria-label="To search for Panda locations, enter your ZIP code or City and State.">
                        <button class="button secondary search-button" type="submit"><span>Search</span></button>
                    </form>
                </div>

                <div class="order-info">
                    <span class="order-text" data-has-time-label="Start an order now and get your food in as little as" data-no-time-label="Start an order now and skip the line!"></span>
                    <span class="order-time"></span>
                    <button class="button secondary large" data-order-now-button>Order Now!</button>
                    <span class="legal">*Pickup time is estimated and may change based on items ordered or other circumstances beyond our control. Actual pickup time will be determined upon completing order.</span>
                </div>
            </div>
            <button class="toggle-submenu" aria-label="Close the Submenu">Hide</button>
        </div>
    </div>

</nav>
        
        <main>
            <a id="skip-to-content" tabindex="-1" class="visually-hidden"></a>
            <div class="row content-container">
                
                

<p><h3 style="text-align: center;">Sorry, we can't seem to find that page.&nbsp;</h3><p style="text-align: center; ">Please double check your URL or try some of our helpful links below.</p><p style="text-align: center; "><br></p><div class="row">    <!-- Black Initial Overlay -->  <a href="https://orders.pandaexpress.com/mp/nd/sites/desktop/Dashboard/" class="image-button-tile c3-l c6-m c6-s black" data-bg-cover="https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/error/Order.png" style="background-image: url(https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/error/Order.png)">    <div class="tile-wrapper">      <div class="tile-container">        <span class="title">Order Online</span>          </div>    </div>  </a>    <!-- No Subtext -->  <a href="https://www.pandaexpress.com/Fundraiser-Landing" class="image-button-tile c3-l c6-m c6-s black" data-bg-cover="https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/error/Group.png" style="background-image: url(https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/error/Group.png)">    <div class="tile-wrapper">      <div class="tile-container">        <span class="title">Fundraising</span>      </div>    </div>  </a>    <a href="https://www.pandaexpress.com/menu/entrees" class="image-button-tile c3-l c6-m c6-s black " data-bg-cover="https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/food/navigation/entrees.jpg" style="background-image: url(https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/food/navigation/entrees.jpg)">    <div class="tile-wrapper">      <div class="tile-container">        <span class="title">Entrees</span>      </div>    </div>  </a>    <a href="https://www.pandaexpress.com/menu/sides" class="image-button-tile c3-l c6-m c6-s black" data-bg-cover="https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/food/navigation/sidedishes.jpg" style="background-image: url(https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/food/navigation/sidedishes.jpg)">    <div class="tile-wrapper">      <div class="tile-container">        <span class="title">Sides</span>      </div>    </div>  </a></div></p>
            </div>
            
        </main>
        <a href="#skip-to-top" class="skip-navigation-button">Skip Footer and Return to Top</a>
        <!-- Site Footer -->
<footer class="footer">
    <footer class="footer">    <div class="footer-high">	                    <div class="container">		                    <nav class="footer-menu">			                    <a href="/connectus#/new">Connect With Us</a>			                    <a href="/contactus#/new">Contact Panda</a> <a href="http://www.pandarg.com" target="_blank">Company</a> <a href="/Fundraiser-Landing">Fundraising</a>			                    <a href="/giftcards">Gift Cards</a> <a href="/sitemap">Site Map</a>		                    </nav>		                    <nav class="footer-social-menu">			                    <a class="px-facebook" href="http://www.facebook.com/PandaExpress" target="_blank">facebook</a>			                    <a class="px-twitter" href="https://twitter.com/PandaExpress" target="_blank">twitter</a>			                    <a class="px-youtube" href="https://www.youtube.com/user/PandaExpressTV/featured" target="_blank">youtube</a>			                    <a class="px-instagram" href="http://instagram.com/officialpandaexpress" target="_blank">instagram</a>		                    </nav>	                    </div>                    </div>                    <div class="footer-low">	                    <div class="container">		                    <nav class="footer-sub-menu">			                    <a class="" href="/legal#privacypolicy">Privacy Policy</a>			                    <a class="" href="/legal#legalstatement">Legal Statement</a>			                    <a class="" href="/legal#casupplychainact">CA Supply Chain Act</a><a class="" href="/accessibility">Accessibility Statement</a>			                    		                    </nav>		                    <div class="footer-app-links">			                    <a class="apple-appstore" href="https://itunes.apple.com/us/app/panda-express-chinese-kitchen/id903990394?mt=8">Download our Apple app in the Appstore</a>			                    <a class="google-playstore" href="https://play.google.com/store/apps/details?id=com.pandaexpress.app">Download our Android app in the Play store</a>		                    </div>		                    <span class="footer-disclaimer">© 2017 Panda Restaurant Group, Inc. All Rights Reserved.</span>	                    </div>                    </div></footer>
</footer>
        <div class="bottom-frame"></div>
</div>

	<script src="/Content/site/frontendjs?v=p4Zg7LPXHIX36rGAD1KW9U8DQR397VgrzEyAmrWDz1w1"></script>

    <script src="/Content/site/qaptchajs?v=iJwr-MGnDUz9WtMNGhkB5ayNMkGOotnfrzOYaSGixCo1"></script>

    <script src="/Content/qaptcha/QapTcha.jquery.js"></script>

    <script type="text/javascript">
    window.appnamespace = 'panda';
    (function (panda) {
        panda['Error'] = new panda['Error']( {
  "ErrorContentBlocks": [
    {
      "Id": "7bae7848-3c09-45c5-a571-807443d0aeec",
      "Content": "<h3 style=\"text-align: center;\">Sorry, we can't seem to find that page.&nbsp;</h3><p style=\"text-align: center; \">Please double check your URL or try some of our helpful links below.</p><p style=\"text-align: center; \"><br></p><div class=\"row\">    <!-- Black Initial Overlay -->  <a href=\"https://orders.pandaexpress.com/mp/nd/sites/desktop/Dashboard/\" class=\"image-button-tile c3-l c6-m c6-s black\" data-bg-cover=\"https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/error/Order.png\" style=\"background-image: url(https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/error/Order.png)\">    <div class=\"tile-wrapper\">      <div class=\"tile-container\">        <span class=\"title\">Order Online</span>          </div>    </div>  </a>    <!-- No Subtext -->  <a href=\"https://www.pandaexpress.com/Fundraiser-Landing\" class=\"image-button-tile c3-l c6-m c6-s black\" data-bg-cover=\"https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/error/Group.png\" style=\"background-image: url(https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/error/Group.png)\">    <div class=\"tile-wrapper\">      <div class=\"tile-container\">        <span class=\"title\">Fundraising</span>      </div>    </div>  </a>    <a href=\"https://www.pandaexpress.com/menu/entrees\" class=\"image-button-tile c3-l c6-m c6-s black \" data-bg-cover=\"https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/food/navigation/entrees.jpg\" style=\"background-image: url(https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/food/navigation/entrees.jpg)\">    <div class=\"tile-wrapper\">      <div class=\"tile-container\">        <span class=\"title\">Entrees</span>      </div>    </div>  </a>    <a href=\"https://www.pandaexpress.com/menu/sides\" class=\"image-button-tile c3-l c6-m c6-s black\" data-bg-cover=\"https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/food/navigation/sidedishes.jpg\" style=\"background-image: url(https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/food/navigation/sidedishes.jpg)\">    <div class=\"tile-wrapper\">      <div class=\"tile-container\">        <span class=\"title\">Sides</span>      </div>    </div>  </a></div>",
      "Order": 0,
      "Slug": "Forbidden"
    },
    {
      "Id": "2c0db182-329d-40d9-bf99-e0e9ed1ff85e",
      "Content": "<h3 style=\"text-align: center;\">Sorry, we can't seem to find that page.&nbsp;</h3><p style=\"text-align: center; \">Please double check your URL or try some of our helpful links below.</p><p style=\"text-align: center; \"><br></p><div class=\"row\">    <!-- Black Initial Overlay -->  <a href=\"https://orders.pandaexpress.com/mp/nd/sites/desktop/Dashboard/\" class=\"image-button-tile c3-l c6-m c6-s black\" data-bg-cover=\"https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/error/Order.png\" style=\"background-image: url(https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/error/Order.png)\">    <div class=\"tile-wrapper\">      <div class=\"tile-container\">        <span class=\"title\">Order Online</span>          </div>    </div>  </a>    <!-- No Subtext -->  <a href=\"https://www.pandaexpress.com/Fundraiser-Landing\" class=\"image-button-tile c3-l c6-m c6-s black\" data-bg-cover=\"https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/error/Group.png\" style=\"background-image: url(https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/error/Group.png)\">    <div class=\"tile-wrapper\">      <div class=\"tile-container\">        <span class=\"title\">Fundraising</span>      </div>    </div>  </a>    <a href=\"https://www.pandaexpress.com/menu/entrees\" class=\"image-button-tile c3-l c6-m c6-s black \" data-bg-cover=\"https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/food/navigation/entrees.jpg\" style=\"background-image: url(https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/food/navigation/entrees.jpg)\">    <div class=\"tile-wrapper\">      <div class=\"tile-container\">        <span class=\"title\">Entrees</span>      </div>    </div>  </a>    <a href=\"https://www.pandaexpress.com/menu/sides\" class=\"image-button-tile c3-l c6-m c6-s black\" data-bg-cover=\"https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/food/navigation/sidedishes.jpg\" style=\"background-image: url(https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/food/navigation/sidedishes.jpg)\">    <div class=\"tile-wrapper\">      <div class=\"tile-container\">        <span class=\"title\">Sides</span>      </div>    </div>  </a></div>",
      "Order": 0,
      "Slug": "PageNotFound"
    },
    {
      "Id": "00bc3eb0-a666-4724-84b2-eb2cd36fc26c",
      "Content": "<h3 style=\"text-align: center;\">Sorry, we can't seem to find that page.&nbsp;</h3><p style=\"text-align: center; \">Please double check your URL or try some of our helpful links below.</p><p style=\"text-align: center; \"><br></p><div class=\"row\">    <!-- Black Initial Overlay -->  <a href=\"https://orders.pandaexpress.com/mp/nd/sites/desktop/Dashboard/\" class=\"image-button-tile c3-l c6-m c6-s black\" data-bg-cover=\"https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/error/Order.png\" style=\"background-image: url(https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/error/Order.png)\">    <div class=\"tile-wrapper\">      <div class=\"tile-container\">        <span class=\"title\">Order Online</span>          </div>    </div>  </a>    <!-- No Subtext -->  <a href=\"https://www.pandaexpress.com/Fundraiser-Landing\" class=\"image-button-tile c3-l c6-m c6-s black\" data-bg-cover=\"https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/error/Group.png\" style=\"background-image: url(https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/error/Group.png)\">    <div class=\"tile-wrapper\">      <div class=\"tile-container\">        <span class=\"title\">Fundraising</span>      </div>    </div>  </a>    <a href=\"https://www.pandaexpress.com/menu/entrees\" class=\"image-button-tile c3-l c6-m c6-s black \" data-bg-cover=\"https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/food/navigation/entrees.jpg\" style=\"background-image: url(https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/food/navigation/entrees.jpg)\">    <div class=\"tile-wrapper\">      <div class=\"tile-container\">        <span class=\"title\">Entrees</span>      </div>    </div>  </a>    <a href=\"https://www.pandaexpress.com/menu/sides\" class=\"image-button-tile c3-l c6-m c6-s black\" data-bg-cover=\"https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/food/navigation/sidedishes.jpg\" style=\"background-image: url(https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/food/navigation/sidedishes.jpg)\">    <div class=\"tile-wrapper\">      <div class=\"tile-container\">        <span class=\"title\">Sides</span>      </div>    </div>  </a></div>",
      "Order": 0,
      "Slug": "SystemError"
    },
    {
      "Id": "25c8a614-bf48-4e58-9741-2a201ad8c99c",
      "Content": "<a href=\"/ourfamilystory\" class=\"image-link\">                                  <img class=\"img\" src=\"https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/our-family-story/navigation/Timeline.jpg\" alt=\"Panda Express location\">\t\t                    <span class=\"text\">Timeline</span></a><a href=\"/asian-pacific-american-heritage-month\" class=\"image-link\">                                  <img class=\"img\" src=\"https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/our-family-story/navigation/apahm-thumb.jpg\" alt=\"Inspired kids\">\t\t                    <span class=\"text\">Inspire Originality</span></a><a href=\"http://www.pandacareers.com\" class=\"image-link\">                                  <img class=\"img\" src=\"https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/our-family-story/navigation/Careers.jpg\" alt=\"Employees\">\t\t                    <span class=\"text\">Careers</span></a><a href=\"http://www.pandacares.org\" class=\"image-link\">                                  <img class=\"img\" src=\"https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/our-family-story/navigation/Panda-Cares.jpg\" alt=\"Panda Cares panda with child\">\t\t                    <span class=\"text\">Panda Cares</span></a><div class=\"link-list\"><a href=\"/ourfamilystory/about\">About Us</a>&nbsp;<a href=\"http://www.pandarg.com\">Panda Restaurant Group, Inc.</a>&nbsp;<a href=\"/american-chinese/#1\">American Chinese</a>&nbsp;</div>",
      "Order": 0,
      "Slug": "OurFamilyStoreSubMenu"
    },
    {
      "Id": "53941511-7edc-4557-85e0-657a9e4568d5",
      "Content": "<footer class=\"footer\">    <div class=\"footer-high\">\t                    <div class=\"container\">\t\t                    <nav class=\"footer-menu\">\t\t\t                    <a href=\"/connectus#/new\">Connect With Us</a>\t\t\t                    <a href=\"/contactus#/new\">Contact Panda</a> <a href=\"http://www.pandarg.com\" target=\"_blank\">Company</a> <a href=\"/Fundraiser-Landing\">Fundraising</a>\t\t\t                    <a href=\"/giftcards\">Gift Cards</a> <a href=\"/sitemap\">Site Map</a>\t\t                    </nav>\t\t                    <nav class=\"footer-social-menu\">\t\t\t                    <a class=\"px-facebook\" href=\"http://www.facebook.com/PandaExpress\" target=\"_blank\">facebook</a>\t\t\t                    <a class=\"px-twitter\" href=\"https://twitter.com/PandaExpress\" target=\"_blank\">twitter</a>\t\t\t                    <a class=\"px-youtube\" href=\"https://www.youtube.com/user/PandaExpressTV/featured\" target=\"_blank\">youtube</a>\t\t\t                    <a class=\"px-instagram\" href=\"http://instagram.com/officialpandaexpress\" target=\"_blank\">instagram</a>\t\t                    </nav>\t                    </div>                    </div>                    <div class=\"footer-low\">\t                    <div class=\"container\">\t\t                    <nav class=\"footer-sub-menu\">\t\t\t                    <a class=\"\" href=\"/legal#privacypolicy\">Privacy Policy</a>\t\t\t                    <a class=\"\" href=\"/legal#legalstatement\">Legal Statement</a>\t\t\t                    <a class=\"\" href=\"/legal#casupplychainact\">CA Supply Chain Act</a><a class=\"\" href=\"/accessibility\">Accessibility Statement</a>\t\t\t                    \t\t                    </nav>\t\t                    <div class=\"footer-app-links\">\t\t\t                    <a class=\"apple-appstore\" href=\"https://itunes.apple.com/us/app/panda-express-chinese-kitchen/id903990394?mt=8\">Download our Apple app in the Appstore</a>\t\t\t                    <a class=\"google-playstore\" href=\"https://play.google.com/store/apps/details?id=com.pandaexpress.app\">Download our Android app in the Play store</a>\t\t                    </div>\t\t                    <span class=\"footer-disclaimer\">© 2017 Panda Restaurant Group, Inc. All Rights Reserved.</span>\t                    </div>                    </div></footer>",
      "Order": 1,
      "Slug": "BottomNav"
    },
    {
      "Id": "2c753b4c-e424-4e5b-95db-65e8361bccae",
      "Content": "<p></p><h1>Frequently Asked Questions</h1><h1><br></h1><h1></h1><h6>Which organizations qualify for fundraisers?</h6><p class=\"p2\">Organizations must be recognized by the Federal government as tax-exempt under Section 501(c)(3) of the Internal Revenue Code. For more information about 501(c)(3) tax status, please visit the <a href=\"http://apps.irs.gov/app/eos/mainSearch.do;jsessionid=rGFfQ9gFhqncCjp9h11RcT8G8FFGGQngwhYRGvnhMcLCWWBzlrHt!2758571?mainSearchChoice=pub78&amp;dispatchMethod=selectSearch\">IRS website</a>.&nbsp;</p><p class=\"p2\">Organizations that have taken part in Panda Express fundraisers include:</p><p class=\"p2\"><span class=\"Apple-tab-span\">\t</span>1.<span class=\"Apple-tab-span\">\t</span>Booster Clubs<br><span style=\"line-height: 1.42857143;\">2.</span><span class=\"Apple-tab-span\" style=\"line-height: 1.42857143;\">\t</span><span style=\"line-height: 1.42857143;\">Boy Scouts<br></span><span style=\"line-height: 1.42857143;\">3.</span><span class=\"Apple-tab-span\" style=\"line-height: 1.42857143;\">\t</span><span style=\"line-height: 1.42857143;\">Camps<br></span><span style=\"line-height: 1.42857143;\">4.</span><span class=\"Apple-tab-span\" style=\"line-height: 1.42857143;\">\t</span><span style=\"line-height: 1.42857143;\">Cheerleading Squads<br></span><span style=\"line-height: 1.42857143;\">5.</span><span class=\"Apple-tab-span\" style=\"line-height: 1.42857143;\">\t</span><span style=\"line-height: 1.42857143;\">Church Groups<br></span><span style=\"line-height: 1.42857143;\">6.</span><span class=\"Apple-tab-span\" style=\"line-height: 1.42857143;\">\t</span><span style=\"line-height: 1.42857143;\">Girl Scouts<br></span><span style=\"line-height: 1.42857143;\">7.</span><span class=\"Apple-tab-span\" style=\"line-height: 1.42857143;\">\t</span><span style=\"line-height: 1.42857143;\">High School Sports Teams<br></span><span style=\"line-height: 1.42857143;\">8.</span><span class=\"Apple-tab-span\" style=\"line-height: 1.42857143;\">\t</span><span style=\"line-height: 1.42857143;\">Parent Teacher Organizations<br></span><span style=\"line-height: 1.42857143;\">9.</span><span class=\"Apple-tab-span\" style=\"line-height: 1.42857143;\">\t</span><span style=\"line-height: 1.42857143;\">Schools<br></span><span style=\"line-height: 1.42857143;\">10.</span><span class=\"Apple-tab-span\" style=\"line-height: 1.42857143;\">\t</span><span style=\"line-height: 1.42857143;\">School Bands<br></span><span style=\"line-height: 1.42857143;\">11.</span><span class=\"Apple-tab-span\" style=\"line-height: 1.42857143;\">\t</span><span style=\"line-height: 1.42857143;\">Sororities/Fraternities<br></span><span style=\"line-height: 1.42857143;\">12.</span><span class=\"Apple-tab-span\" style=\"line-height: 1.42857143;\">\t</span><span style=\"line-height: 1.42857143;\">Student Councils</span></p><p class=\"p2\"><br></p><h6>What if I do not know my organization's Taxpayer Identification Number?</h6><p class=\"p2\">You will need to contact the leadership of the organization (i.e. School Activities Director, President, etc). &nbsp;Please note, we require the number to be a Federal Taxpayer Identification Number (TIN), we cannot process for individual states. When you have the Federal Taxpayer Identification Number you will be able to reserve your fundraiser.</p><p class=\"p2\"><br></p><h6>What if the organization does not have a Taxpayer Identification Number?</h6><p class=\"p2\">Although there are many caring and giving foundations and we commend you for supporting them, only organizations that have a Taxpayer Identification Number may hold a fundraiser at Panda Express.</p><p class=\"p2\"><br></p><h6>What does my organization get in return?</h6><p class=\"p2\"><span class=\"Apple-tab-span\">\t</span>1.<span class=\"Apple-tab-span\">\t</span>20% of all sales (pre-tax) brought in by your fundraiser will be donated directly to your organization. A check will be issued 4-6 weeks after your event. Gift card purchases are not applicable toward fundraiser sales.<br></p><p class=\"p2\"><span class=\"Apple-tab-span\">\t</span>2.<span class=\"Apple-tab-span\">\t</span>People attending your fundraiser will need to bring their flyers with them, and present them to the cashier when ordering. We accept flyers shown on a phone.<br></p><p class=\"p2\"><span class=\"Apple-tab-span\">\t</span>3.<span class=\"Apple-tab-span\">\t</span>Fundraiser guests are required to present a valid fundraiser flyer with each order to receive credit for the fundraiser.<br></p><p class=\"p2\"><span class=\"Apple-tab-span\">\t</span>4.<span class=\"Apple-tab-span\">\t</span>Guests may receive credit for their meals whether they dine in, take food to go or pick up a Panda Express catering order.<br></p><p class=\"p2\"><span class=\"Apple-tab-span\">\t</span>5.<span class=\"Apple-tab-span\">\t</span>Please note: Flyers cannot be distributed inside Panda Express, within the vicinity of Panda Express including the Panda Express parking lot before or during your event. Thank you for understanding.</p><p class=\"p2\"><br></p><h6>When can my organization host an event?</h6><p class=\"p2\">When you make your reservation online, the calendar will provide available dates at your chosen Panda Express location. Please note that a minimum two week notice is required and you can schedule your fundraiser up to 3 months in advance.</p><p class=\"p2\"><br></p><h6>How often can I schedule fundraisers?</h6><p class=\"p2\">You may schedule one fundraiser every 30 days. At least two-weeks notice is required. You can schedule up to three months in advance.</p><p class=\"p2\"><br></p><h6>Is a flyer available for my event? How do I get it?</h6><p class=\"p2\">Yes, a flyer is available for your event. Once your fundraiser has been approved, you'll be able to access it online by logging into your fundraiser account and clicking the “Review Flyer” link. The flyer will pop up as a PDF, so you can print it and distribute as many as you like. Click <a href=\"https://www.pandaexpress.com/fundraiser/preview?guid=664443c2-1036-4443-a38d-db616fd8346d\">here</a> to see a sample flyer.</p><p class=\"p2\"><br></p><h6>The link to my flyer is not working. What do I do?</h6><p class=\"p2\">If the link is not working, please check to see if a PDF reader is installed on the computer you are using. If there isn't one, a PDF reader will need to be installed to view the flyer.</p><p class=\"p2\">If you do have a PDF reader, please turn off the browser's pop-up blocker or check the firewall.</p><p class=\"p2\">If the issue persists, please email FundRaiserCenter@pandarg.com&nbsp;</p><p class=\"p2\"><br></p><h6>The status of my fundraiser says \"Pending\". What does that mean?</h6><p class=\"p2\"></p><p>If the status of your event says \"Pending\", that means that the fundraiser application did not come through and will need to be resubmitted. To resubmit the application, click on \"View\", verify the information, and click on the button that says \"Submit My Fundraiser\". You will receive an email confirmation of the submission and the status will change to \"Submitted\".</p><br><p></p><h6>&nbsp;How do I know if my fundraiser event has been approved?</h6><p class=\"p2\">First, you will receive an email confirmation that we received your fundraiser submission. If you did not receive this email, go back into your account to submit your application. Next, an email will be sent to you within 48 hours notifying you if the fundraiser has been approved or declined.</p><p class=\"p2\">**As a courtesy to the store location, please do not start advertising your fundraiser until you have received confirmation of its approval.</p><p class=\"p2\"><br></p><h6>How do I change the date and time of my confirmed fundraiser?</h6><p class=\"p2\">Please note, fundraiser dates and times cannot be changed within 72 hours of the event. To make changes, please contact our Fundraiser Team at FundraiserCenter@pandarg.com.</p><p class=\"p2\"><br></p><h6>How do I cancel my fundraiser?</h6><p class=\"p2\">You may cancel your fundraiser with a minimum of 72 hours notice prior to the scheduled event by logging into your Panda Express fundraiser account. Please note, any cancellation notice of less than 72 hours may affect any future fundraiser event requests.</p><p class=\"p2\"><br></p><h6>How will I know how much money my organization made?</h6><p class=\"p2\">Your fundraiser donation will show on your fundraiser account. If it is not there three days after the event, please email FundraiserCenter@PandaRG.com for the results.</p><p class=\"p2\"><br></p><h6>When can I expect my fundraiser check?</h6><p class=\"p2\">Please allow four to six weeks for processing your fundraiser check (does not include delivery time). If it has been more than eight weeks since your event and you still have not received a check, please contact our Fundraiser Team at FundraiserCenter@pandarg.com.</p><p class=\"p2\">****Due to the holiday season and the high number of fundraisers, checks will be delayed one-two weeks. We thank you for your patience in advance.</p><p class=\"p2\"><br></p><p class=\"p2\" style=\"margin-left: 25px;\"><br></p><p></p>",
      "Order": 0,
      "Slug": "FundraiserFAQ"
    },
    {
      "Id": "c5a5fa1b-60fa-4c1d-bb95-6cd7514bb471",
      "Content": "<p><br></p>",
      "Order": 0,
      "Slug": "MenuSideNavSecondary"
    },
    {
      "Id": "ea9fe356-95d0-498b-b342-7f71f030d7f0",
      "Content": "<h1>Helpful Fundraising Tips</h1>                                            <div class=\"tip-box\">                                                <span class=\"title\">What turns a Fundraiser into an Event? </span>                                                <span class=\"tip\">Just add a bit more flare and fun. Build excitement and get a BIG turnout at each Fundraiser by using A-frame signs, banners, reminder stickers and the Panda mascot at your nonprofit Partner Organizations location. When Guests visit your store, greet them with a banner, coloring contest, balloons and more. Make every Fundraiser an Event!</span>                                            </div>",
      "Order": 0,
      "Slug": "FundraisingTips"
    },
    {
      "Id": "687c581f-68c8-41c0-ac6a-a51963be5db3",
      "Content": "<ul class=\"mobile-nav\"><!--   <li><a class=\"mobile-link\" data-ga-event-menu=\"ourfamilystory\" href=\"/ourfamilystory\">Our Family Story</a></li>-->        <li>            <button class=\"submenu-link\" data-active=\"false\" data-mobile-sublink=\"\">Our Family Story</button>            <div class=\"submenu\">                <button class=\"mobile-back\" data-mobile-back=\"\">Our Family Story</button>                <a class=\"mobile-link\" href=\"/ourfamilystory\">Timeline</a>         <a class=\"mobile-link\" href=\"/american-chinese/#1\">American Chinese</a>       <a class=\"mobile-link\" href=\"/ourfamilystory/about\">About Us</a>                            <a class=\"mobile-link\" href=\"http://www.pandacareers.com\">Careers</a> <a class=\"mobile-link\" href=\"http://www.pandacares.org\">Panda Cares</a>             <a class=\"mobile-link\" href=\"http://www.pandarg.com\">Panda Restaurant Group, Inc.</a>           </div>        </li><li>            <button class=\"submenu-link\" data-active=\"false\" data-mobile-sublink=\"\">Fundraising</button>            <div class=\"submenu\">                <button class=\"mobile-back\" data-mobile-back=\"\">Fundraising</button>                <a class=\"mobile-link\" href=\"/fundraiser-landing\">Learn More</a>                <a class=\"mobile-link\" href=\"/fundraiserlogin\">Login/Register</a>                <a class=\"mobile-link\" href=\"/pandafundraisermember\">My Account</a>                <a class=\"mobile-link\" href=\"/fundraiserlogin/FAQ\">Frequently Asked Questions</a>                <a class=\"mobile-link\" href=\"/fundraiserlogin/helpfulfundraisingtips\">Helpful Fundraising Tips</a>            </div>        </li>        <li><a class=\"mobile-link\" data-ga-event-menu=\"Wok Smart\" href=\"/wok-smart\">Wok Smart</a></li>        <li><a class=\"mobile-link\" data-ga-event-menu=\"Masters Of The Wok\" href=\"/wok\">Masters Of The Wok</a></li>        <li><a class=\"mobile-link\" data-ga-event-menu=\"Connect\" href=\"/connectus\">Connect With Us</a></li>        <li><a class=\"mobile-link\" data-ga-event-menu=\"Contact\" href=\"/contactus\">Contact Panda</a></li>        <li><a class=\"mobile-link\" data-ga-event-menu=\"Company\" href=\"http://www.pandarg.com\">Company</a></li>        <li><a class=\"mobile-link\" data-ga-event-menu=\"Gift Cards\" href=\"/giftcards\">Gift Cards</a></li>        <li><a class=\"mobile-link\" data-ga-event-menu=\"Site Map\" href=\"/sitemap\">Site Map</a></li>        <li><a class=\"mobile-link\" href=\"/legal#privacypolicy\">Privacy Policy</a></li>        <li><a class=\"mobile-link\" href=\"/legal#legalstatement\">Legal Statement</a></li>        <li><a class=\"mobile-link\" href=\"/legal#casupplychainact\">CA Supply Chain Act</a></li>        <li><a class=\"mobile-link\" href=\"/accessibility\">Accessibility Statement</a></li>        <!--        <li>            <button class=\"submenu-link\" data-active=\"false\" data-mobile-sublink>Legal Statement</button>            <div class=\"submenu\">                <button class=\"mobile-back\" data-mobile-back>Legal Statement</button>                <a class=\"mobile-link\" href=\"/legal#privacypolicy\">Privacy Policy</a>                <a class=\"mobile-link\" href=\"/legal#legalstatement\">Legal Statement</a>                <a class=\"mobile-link\" href=\"/legal#casupplychainact\">CA Supply Chain Act</a>            </div>        </li>        -->    </ul>",
      "Order": 0,
      "Slug": "MobileNav"
    },
    {
      "Id": "23f09af6-781a-418c-8dd4-a8c3cdb7a4b1",
      "Content": "<li data-active=\"false\">                <a href=\"/pandafundraiser/fundraiserfaq\" data-active=\"false\">Frequently Asked Questions</a>            </li><li data-active=\"false\"><a href=\"/pandafundraiser/helpfulfundraisingtips\" data-active=\"false\">Helpful Fundraising Tips</a></li>",
      "Order": 0,
      "Slug": "FundraiserSideNavSecondary"
    },
    {
      "Id": "6581be08-f35f-46ea-8fe4-ca7f9c7521c6",
      "Content": "<a href=\"/how-to-order\" class=\"image-link\">\t\t                    <img src=\"https://s3.amazonaws.com/PandaExpressWebsite/img/favorites/fav-menu.jpg\" alt=\"Panda Favorites\">\t\t                    <span class=\"text\">Panda Favorites</span>\t                    </a><a href=\"/menu/entrees\" class=\"image-link\">\t\t                    <img class=\"img\" src=\"https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/food/navigation/entrees.jpg\" alt=\"Entrees\">\t\t                    <span class=\"text\">Entrees</span>\t                    </a>\t                    <a href=\"/menu/sides\" class=\"image-link\">\t\t                    <img src=\"https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/food/navigation/sidedishes.jpg\" alt=\"Sides\">\t\t                    <span class=\"text\">Sides</span>\t                    </a>\t                    <a href=\"/menu/appetizers\" class=\"image-link\">\t\t                    <img src=\"https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/food/navigation/appetizers.jpg\" alt=\"Appetizers\">\t\t                    <span class=\"text\">Appetizers</span>\t                    </a>\t                   \t                    <div class=\"link-list\"><a href=\"/how-to-order?tab=2\">How to Panda</a>&nbsp;<a href=\"/menu/desserts\">Desserts</a>&nbsp;<a href=\"/Catering\">Catering</a>&nbsp;<a href=\"/wok-smart\">Wok Smart</a>&nbsp;<a href=\"/innovationkitchen\">Innovation Kitchen</a>&nbsp;<a href=\"/teabar\">Tea Bar</a>&nbsp;<a href=\"/pandasfuture\">Taste the Future</a>&nbsp;<a href=\"/masters-of-flavor\">Masters of Flavor</a><a href=\"/wok\">Masters of the Wok</a>&nbsp;<a href=\"https://s3.amazonaws.com/PandaExpressWebsite/files/pdf/Nutrition.pdf\" target=\"_blank\">Download Nutrition PDF</a></div>",
      "Order": 0,
      "Slug": "OurFoodSubMenu"
    }
  ],
  "List": [],
  "Item": {
    "Id": 0,
    "ClientId": null
  },
  "ItemDetail": {
    "Id": 0,
    "ClientId": null
  },
  "PageInfo": {
    "Id": "00000000-0000-0000-0000-000000000000",
    "PageCount": 0,
    "TotalItemCount": 0,
    "PageNumber": 0,
    "PageSize": 0,
    "HasPreviousPage": false,
    "HasNextPage": false,
    "IsFirstPage": false,
    "IsLastPage": false,
    "FirstItemOnPage": 0,
    "LastItemOnPage": 0,
    "Page1": null,
    "Page2": null,
    "Page3": null,
    "Page4": null,
    "Page5": null,
    "ClientId": null
  },
  "ItemDetailIsNew": false,
  "Columns": [
    {
      "DisplayName": "Id",
      "ColumnName": "Id",
      "SortColumn": "Id",
      "DisableSort": false,
      "Format": {
        "Binding": "html",
        "FormatString": null
      },
      "IsHidden": false,
      "IsSortedUp": false,
      "IsSortedDown": false
    },
    {
      "DisplayName": "Client Id",
      "ColumnName": "ClientId",
      "SortColumn": "ClientId",
      "DisableSort": false,
      "Format": {
        "Binding": "html",
        "FormatString": null
      },
      "IsHidden": true,
      "IsSortedUp": false,
      "IsSortedDown": false
    }
  ],
  "IsDynamicTable": false,
  "OverrideConcurrencyError": false,
  "OpenDynamicId": null,
  "ModalOpen": false,
  "EditAction": "InsertUpdate",
  "DefaultEditAction": "InsertUpdate",
  "DefaultPageSize": 10,
  "Alerts": [],
  "FormVisible": false,
  "Area": "Admin",
  "ActiveTabIndex": 0,
  "FormTabs": [],
  "NavActive": null,
  "RootUrl": null,
  "DefaultLanguage": "en",
  "ZeroDayNavs": false,
  "PageContentId": null,
  "HasAlerts": true,
  "HasDialog": false,
  "HasExport": false,
  "AllowEditing": true,
  "HideNav": false,
  "HideFooter": false,
  "IsLoading": false,
  "IsRowLoading": false,
  "IsTableLoading": false,
  "LeaveOpenOnAjaxSuccess": false,
  "DefaultSammyRoute": "list",
  "StatusCode": 200,
  "KOMapping": {
    "ignore": [],
    "copy": [
      "KOMapping.copy",
      "Meta"
    ],
    "ignorePostBack": [],
    "allNonPostBack": [
      "KOMapping.copy",
      "Meta"
    ]
  },
  "NavigationItems": [],
  "OnlyValidateFields": [],
  "Grid": null,
  "ModelState": {
    "IsValid": false,
    "PropertyErrors": [],
    "ModelErrors": []
  },
  "FormControlClasses": "form-group col-sm-6 col-md-4 col-lg-3",
  "Message": null,
  "RedirectResponse": null,
  "Title": "Error",
  "SkipMenuItemDisplay": "Menu Items",
  "ListTitle": null,
  "Section": null,
  "LeftNav": null,
  "LeftNavTitle": null,
  "TopNav": null,
  "LoggedInUserFirstName": null,
  "User": null,
  "BodyClass": null,
  "CanDelete": false,
  "MetaDescription": null,
  "MetaTags": null,
  "MetaTitle": "Panda Express Chinese Restaurant",
  "ContentBlocks": [
    {
      "Id": "25c8a614-bf48-4e58-9741-2a201ad8c99c",
      "Content": "<a href=\"/ourfamilystory\" class=\"image-link\">                                  <img class=\"img\" src=\"https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/our-family-story/navigation/Timeline.jpg\" alt=\"Panda Express location\">\t\t                    <span class=\"text\">Timeline</span></a><a href=\"/asian-pacific-american-heritage-month\" class=\"image-link\">                                  <img class=\"img\" src=\"https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/our-family-story/navigation/apahm-thumb.jpg\" alt=\"Inspired kids\">\t\t                    <span class=\"text\">Inspire Originality</span></a><a href=\"http://www.pandacareers.com\" class=\"image-link\">                                  <img class=\"img\" src=\"https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/our-family-story/navigation/Careers.jpg\" alt=\"Employees\">\t\t                    <span class=\"text\">Careers</span></a><a href=\"http://www.pandacares.org\" class=\"image-link\">                                  <img class=\"img\" src=\"https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/our-family-story/navigation/Panda-Cares.jpg\" alt=\"Panda Cares panda with child\">\t\t                    <span class=\"text\">Panda Cares</span></a><div class=\"link-list\"><a href=\"/ourfamilystory/about\">About Us</a>&nbsp;<a href=\"http://www.pandarg.com\">Panda Restaurant Group, Inc.</a>&nbsp;<a href=\"/american-chinese/#1\">American Chinese</a>&nbsp;</div>",
      "Order": 0,
      "Slug": "OurFamilyStoreSubMenu"
    },
    {
      "Id": "53941511-7edc-4557-85e0-657a9e4568d5",
      "Content": "<footer class=\"footer\">    <div class=\"footer-high\">\t                    <div class=\"container\">\t\t                    <nav class=\"footer-menu\">\t\t\t                    <a href=\"/connectus#/new\">Connect With Us</a>\t\t\t                    <a href=\"/contactus#/new\">Contact Panda</a> <a href=\"http://www.pandarg.com\" target=\"_blank\">Company</a> <a href=\"/Fundraiser-Landing\">Fundraising</a>\t\t\t                    <a href=\"/giftcards\">Gift Cards</a> <a href=\"/sitemap\">Site Map</a>\t\t                    </nav>\t\t                    <nav class=\"footer-social-menu\">\t\t\t                    <a class=\"px-facebook\" href=\"http://www.facebook.com/PandaExpress\" target=\"_blank\">facebook</a>\t\t\t                    <a class=\"px-twitter\" href=\"https://twitter.com/PandaExpress\" target=\"_blank\">twitter</a>\t\t\t                    <a class=\"px-youtube\" href=\"https://www.youtube.com/user/PandaExpressTV/featured\" target=\"_blank\">youtube</a>\t\t\t                    <a class=\"px-instagram\" href=\"http://instagram.com/officialpandaexpress\" target=\"_blank\">instagram</a>\t\t                    </nav>\t                    </div>                    </div>                    <div class=\"footer-low\">\t                    <div class=\"container\">\t\t                    <nav class=\"footer-sub-menu\">\t\t\t                    <a class=\"\" href=\"/legal#privacypolicy\">Privacy Policy</a>\t\t\t                    <a class=\"\" href=\"/legal#legalstatement\">Legal Statement</a>\t\t\t                    <a class=\"\" href=\"/legal#casupplychainact\">CA Supply Chain Act</a><a class=\"\" href=\"/accessibility\">Accessibility Statement</a>\t\t\t                    \t\t                    </nav>\t\t                    <div class=\"footer-app-links\">\t\t\t                    <a class=\"apple-appstore\" href=\"https://itunes.apple.com/us/app/panda-express-chinese-kitchen/id903990394?mt=8\">Download our Apple app in the Appstore</a>\t\t\t                    <a class=\"google-playstore\" href=\"https://play.google.com/store/apps/details?id=com.pandaexpress.app\">Download our Android app in the Play store</a>\t\t                    </div>\t\t                    <span class=\"footer-disclaimer\">© 2017 Panda Restaurant Group, Inc. All Rights Reserved.</span>\t                    </div>                    </div></footer>",
      "Order": 1,
      "Slug": "BottomNav"
    },
    {
      "Id": "2c753b4c-e424-4e5b-95db-65e8361bccae",
      "Content": "<p></p><h1>Frequently Asked Questions</h1><h1><br></h1><h1></h1><h6>Which organizations qualify for fundraisers?</h6><p class=\"p2\">Organizations must be recognized by the Federal government as tax-exempt under Section 501(c)(3) of the Internal Revenue Code. For more information about 501(c)(3) tax status, please visit the <a href=\"http://apps.irs.gov/app/eos/mainSearch.do;jsessionid=rGFfQ9gFhqncCjp9h11RcT8G8FFGGQngwhYRGvnhMcLCWWBzlrHt!2758571?mainSearchChoice=pub78&amp;dispatchMethod=selectSearch\">IRS website</a>.&nbsp;</p><p class=\"p2\">Organizations that have taken part in Panda Express fundraisers include:</p><p class=\"p2\"><span class=\"Apple-tab-span\">\t</span>1.<span class=\"Apple-tab-span\">\t</span>Booster Clubs<br><span style=\"line-height: 1.42857143;\">2.</span><span class=\"Apple-tab-span\" style=\"line-height: 1.42857143;\">\t</span><span style=\"line-height: 1.42857143;\">Boy Scouts<br></span><span style=\"line-height: 1.42857143;\">3.</span><span class=\"Apple-tab-span\" style=\"line-height: 1.42857143;\">\t</span><span style=\"line-height: 1.42857143;\">Camps<br></span><span style=\"line-height: 1.42857143;\">4.</span><span class=\"Apple-tab-span\" style=\"line-height: 1.42857143;\">\t</span><span style=\"line-height: 1.42857143;\">Cheerleading Squads<br></span><span style=\"line-height: 1.42857143;\">5.</span><span class=\"Apple-tab-span\" style=\"line-height: 1.42857143;\">\t</span><span style=\"line-height: 1.42857143;\">Church Groups<br></span><span style=\"line-height: 1.42857143;\">6.</span><span class=\"Apple-tab-span\" style=\"line-height: 1.42857143;\">\t</span><span style=\"line-height: 1.42857143;\">Girl Scouts<br></span><span style=\"line-height: 1.42857143;\">7.</span><span class=\"Apple-tab-span\" style=\"line-height: 1.42857143;\">\t</span><span style=\"line-height: 1.42857143;\">High School Sports Teams<br></span><span style=\"line-height: 1.42857143;\">8.</span><span class=\"Apple-tab-span\" style=\"line-height: 1.42857143;\">\t</span><span style=\"line-height: 1.42857143;\">Parent Teacher Organizations<br></span><span style=\"line-height: 1.42857143;\">9.</span><span class=\"Apple-tab-span\" style=\"line-height: 1.42857143;\">\t</span><span style=\"line-height: 1.42857143;\">Schools<br></span><span style=\"line-height: 1.42857143;\">10.</span><span class=\"Apple-tab-span\" style=\"line-height: 1.42857143;\">\t</span><span style=\"line-height: 1.42857143;\">School Bands<br></span><span style=\"line-height: 1.42857143;\">11.</span><span class=\"Apple-tab-span\" style=\"line-height: 1.42857143;\">\t</span><span style=\"line-height: 1.42857143;\">Sororities/Fraternities<br></span><span style=\"line-height: 1.42857143;\">12.</span><span class=\"Apple-tab-span\" style=\"line-height: 1.42857143;\">\t</span><span style=\"line-height: 1.42857143;\">Student Councils</span></p><p class=\"p2\"><br></p><h6>What if I do not know my organization's Taxpayer Identification Number?</h6><p class=\"p2\">You will need to contact the leadership of the organization (i.e. School Activities Director, President, etc). &nbsp;Please note, we require the number to be a Federal Taxpayer Identification Number (TIN), we cannot process for individual states. When you have the Federal Taxpayer Identification Number you will be able to reserve your fundraiser.</p><p class=\"p2\"><br></p><h6>What if the organization does not have a Taxpayer Identification Number?</h6><p class=\"p2\">Although there are many caring and giving foundations and we commend you for supporting them, only organizations that have a Taxpayer Identification Number may hold a fundraiser at Panda Express.</p><p class=\"p2\"><br></p><h6>What does my organization get in return?</h6><p class=\"p2\"><span class=\"Apple-tab-span\">\t</span>1.<span class=\"Apple-tab-span\">\t</span>20% of all sales (pre-tax) brought in by your fundraiser will be donated directly to your organization. A check will be issued 4-6 weeks after your event. Gift card purchases are not applicable toward fundraiser sales.<br></p><p class=\"p2\"><span class=\"Apple-tab-span\">\t</span>2.<span class=\"Apple-tab-span\">\t</span>People attending your fundraiser will need to bring their flyers with them, and present them to the cashier when ordering. We accept flyers shown on a phone.<br></p><p class=\"p2\"><span class=\"Apple-tab-span\">\t</span>3.<span class=\"Apple-tab-span\">\t</span>Fundraiser guests are required to present a valid fundraiser flyer with each order to receive credit for the fundraiser.<br></p><p class=\"p2\"><span class=\"Apple-tab-span\">\t</span>4.<span class=\"Apple-tab-span\">\t</span>Guests may receive credit for their meals whether they dine in, take food to go or pick up a Panda Express catering order.<br></p><p class=\"p2\"><span class=\"Apple-tab-span\">\t</span>5.<span class=\"Apple-tab-span\">\t</span>Please note: Flyers cannot be distributed inside Panda Express, within the vicinity of Panda Express including the Panda Express parking lot before or during your event. Thank you for understanding.</p><p class=\"p2\"><br></p><h6>When can my organization host an event?</h6><p class=\"p2\">When you make your reservation online, the calendar will provide available dates at your chosen Panda Express location. Please note that a minimum two week notice is required and you can schedule your fundraiser up to 3 months in advance.</p><p class=\"p2\"><br></p><h6>How often can I schedule fundraisers?</h6><p class=\"p2\">You may schedule one fundraiser every 30 days. At least two-weeks notice is required. You can schedule up to three months in advance.</p><p class=\"p2\"><br></p><h6>Is a flyer available for my event? How do I get it?</h6><p class=\"p2\">Yes, a flyer is available for your event. Once your fundraiser has been approved, you'll be able to access it online by logging into your fundraiser account and clicking the “Review Flyer” link. The flyer will pop up as a PDF, so you can print it and distribute as many as you like. Click <a href=\"https://www.pandaexpress.com/fundraiser/preview?guid=664443c2-1036-4443-a38d-db616fd8346d\">here</a> to see a sample flyer.</p><p class=\"p2\"><br></p><h6>The link to my flyer is not working. What do I do?</h6><p class=\"p2\">If the link is not working, please check to see if a PDF reader is installed on the computer you are using. If there isn't one, a PDF reader will need to be installed to view the flyer.</p><p class=\"p2\">If you do have a PDF reader, please turn off the browser's pop-up blocker or check the firewall.</p><p class=\"p2\">If the issue persists, please email FundRaiserCenter@pandarg.com&nbsp;</p><p class=\"p2\"><br></p><h6>The status of my fundraiser says \"Pending\". What does that mean?</h6><p class=\"p2\"></p><p>If the status of your event says \"Pending\", that means that the fundraiser application did not come through and will need to be resubmitted. To resubmit the application, click on \"View\", verify the information, and click on the button that says \"Submit My Fundraiser\". You will receive an email confirmation of the submission and the status will change to \"Submitted\".</p><br><p></p><h6>&nbsp;How do I know if my fundraiser event has been approved?</h6><p class=\"p2\">First, you will receive an email confirmation that we received your fundraiser submission. If you did not receive this email, go back into your account to submit your application. Next, an email will be sent to you within 48 hours notifying you if the fundraiser has been approved or declined.</p><p class=\"p2\">**As a courtesy to the store location, please do not start advertising your fundraiser until you have received confirmation of its approval.</p><p class=\"p2\"><br></p><h6>How do I change the date and time of my confirmed fundraiser?</h6><p class=\"p2\">Please note, fundraiser dates and times cannot be changed within 72 hours of the event. To make changes, please contact our Fundraiser Team at FundraiserCenter@pandarg.com.</p><p class=\"p2\"><br></p><h6>How do I cancel my fundraiser?</h6><p class=\"p2\">You may cancel your fundraiser with a minimum of 72 hours notice prior to the scheduled event by logging into your Panda Express fundraiser account. Please note, any cancellation notice of less than 72 hours may affect any future fundraiser event requests.</p><p class=\"p2\"><br></p><h6>How will I know how much money my organization made?</h6><p class=\"p2\">Your fundraiser donation will show on your fundraiser account. If it is not there three days after the event, please email FundraiserCenter@PandaRG.com for the results.</p><p class=\"p2\"><br></p><h6>When can I expect my fundraiser check?</h6><p class=\"p2\">Please allow four to six weeks for processing your fundraiser check (does not include delivery time). If it has been more than eight weeks since your event and you still have not received a check, please contact our Fundraiser Team at FundraiserCenter@pandarg.com.</p><p class=\"p2\">****Due to the holiday season and the high number of fundraisers, checks will be delayed one-two weeks. We thank you for your patience in advance.</p><p class=\"p2\"><br></p><p class=\"p2\" style=\"margin-left: 25px;\"><br></p><p></p>",
      "Order": 0,
      "Slug": "FundraiserFAQ"
    },
    {
      "Id": "c5a5fa1b-60fa-4c1d-bb95-6cd7514bb471",
      "Content": "<p><br></p>",
      "Order": 0,
      "Slug": "MenuSideNavSecondary"
    },
    {
      "Id": "ea9fe356-95d0-498b-b342-7f71f030d7f0",
      "Content": "<h1>Helpful Fundraising Tips</h1>                                            <div class=\"tip-box\">                                                <span class=\"title\">What turns a Fundraiser into an Event? </span>                                                <span class=\"tip\">Just add a bit more flare and fun. Build excitement and get a BIG turnout at each Fundraiser by using A-frame signs, banners, reminder stickers and the Panda mascot at your nonprofit Partner Organizations location. When Guests visit your store, greet them with a banner, coloring contest, balloons and more. Make every Fundraiser an Event!</span>                                            </div>",
      "Order": 0,
      "Slug": "FundraisingTips"
    },
    {
      "Id": "687c581f-68c8-41c0-ac6a-a51963be5db3",
      "Content": "<ul class=\"mobile-nav\"><!--   <li><a class=\"mobile-link\" data-ga-event-menu=\"ourfamilystory\" href=\"/ourfamilystory\">Our Family Story</a></li>-->        <li>            <button class=\"submenu-link\" data-active=\"false\" data-mobile-sublink=\"\">Our Family Story</button>            <div class=\"submenu\">                <button class=\"mobile-back\" data-mobile-back=\"\">Our Family Story</button>                <a class=\"mobile-link\" href=\"/ourfamilystory\">Timeline</a>         <a class=\"mobile-link\" href=\"/american-chinese/#1\">American Chinese</a>       <a class=\"mobile-link\" href=\"/ourfamilystory/about\">About Us</a>                            <a class=\"mobile-link\" href=\"http://www.pandacareers.com\">Careers</a> <a class=\"mobile-link\" href=\"http://www.pandacares.org\">Panda Cares</a>             <a class=\"mobile-link\" href=\"http://www.pandarg.com\">Panda Restaurant Group, Inc.</a>           </div>        </li><li>            <button class=\"submenu-link\" data-active=\"false\" data-mobile-sublink=\"\">Fundraising</button>            <div class=\"submenu\">                <button class=\"mobile-back\" data-mobile-back=\"\">Fundraising</button>                <a class=\"mobile-link\" href=\"/fundraiser-landing\">Learn More</a>                <a class=\"mobile-link\" href=\"/fundraiserlogin\">Login/Register</a>                <a class=\"mobile-link\" href=\"/pandafundraisermember\">My Account</a>                <a class=\"mobile-link\" href=\"/fundraiserlogin/FAQ\">Frequently Asked Questions</a>                <a class=\"mobile-link\" href=\"/fundraiserlogin/helpfulfundraisingtips\">Helpful Fundraising Tips</a>            </div>        </li>        <li><a class=\"mobile-link\" data-ga-event-menu=\"Wok Smart\" href=\"/wok-smart\">Wok Smart</a></li>        <li><a class=\"mobile-link\" data-ga-event-menu=\"Masters Of The Wok\" href=\"/wok\">Masters Of The Wok</a></li>        <li><a class=\"mobile-link\" data-ga-event-menu=\"Connect\" href=\"/connectus\">Connect With Us</a></li>        <li><a class=\"mobile-link\" data-ga-event-menu=\"Contact\" href=\"/contactus\">Contact Panda</a></li>        <li><a class=\"mobile-link\" data-ga-event-menu=\"Company\" href=\"http://www.pandarg.com\">Company</a></li>        <li><a class=\"mobile-link\" data-ga-event-menu=\"Gift Cards\" href=\"/giftcards\">Gift Cards</a></li>        <li><a class=\"mobile-link\" data-ga-event-menu=\"Site Map\" href=\"/sitemap\">Site Map</a></li>        <li><a class=\"mobile-link\" href=\"/legal#privacypolicy\">Privacy Policy</a></li>        <li><a class=\"mobile-link\" href=\"/legal#legalstatement\">Legal Statement</a></li>        <li><a class=\"mobile-link\" href=\"/legal#casupplychainact\">CA Supply Chain Act</a></li>        <li><a class=\"mobile-link\" href=\"/accessibility\">Accessibility Statement</a></li>        <!--        <li>            <button class=\"submenu-link\" data-active=\"false\" data-mobile-sublink>Legal Statement</button>            <div class=\"submenu\">                <button class=\"mobile-back\" data-mobile-back>Legal Statement</button>                <a class=\"mobile-link\" href=\"/legal#privacypolicy\">Privacy Policy</a>                <a class=\"mobile-link\" href=\"/legal#legalstatement\">Legal Statement</a>                <a class=\"mobile-link\" href=\"/legal#casupplychainact\">CA Supply Chain Act</a>            </div>        </li>        -->    </ul>",
      "Order": 0,
      "Slug": "MobileNav"
    },
    {
      "Id": "23f09af6-781a-418c-8dd4-a8c3cdb7a4b1",
      "Content": "<li data-active=\"false\">                <a href=\"/pandafundraiser/fundraiserfaq\" data-active=\"false\">Frequently Asked Questions</a>            </li><li data-active=\"false\"><a href=\"/pandafundraiser/helpfulfundraisingtips\" data-active=\"false\">Helpful Fundraising Tips</a></li>",
      "Order": 0,
      "Slug": "FundraiserSideNavSecondary"
    },
    {
      "Id": "6581be08-f35f-46ea-8fe4-ca7f9c7521c6",
      "Content": "<a href=\"/how-to-order\" class=\"image-link\">\t\t                    <img src=\"https://s3.amazonaws.com/PandaExpressWebsite/img/favorites/fav-menu.jpg\" alt=\"Panda Favorites\">\t\t                    <span class=\"text\">Panda Favorites</span>\t                    </a><a href=\"/menu/entrees\" class=\"image-link\">\t\t                    <img class=\"img\" src=\"https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/food/navigation/entrees.jpg\" alt=\"Entrees\">\t\t                    <span class=\"text\">Entrees</span>\t                    </a>\t                    <a href=\"/menu/sides\" class=\"image-link\">\t\t                    <img src=\"https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/food/navigation/sidedishes.jpg\" alt=\"Sides\">\t\t                    <span class=\"text\">Sides</span>\t                    </a>\t                    <a href=\"/menu/appetizers\" class=\"image-link\">\t\t                    <img src=\"https://s3.amazonaws.com/PandaExpressWebsite/Responsive/img/food/navigation/appetizers.jpg\" alt=\"Appetizers\">\t\t                    <span class=\"text\">Appetizers</span>\t                    </a>\t                   \t                    <div class=\"link-list\"><a href=\"/how-to-order?tab=2\">How to Panda</a>&nbsp;<a href=\"/menu/desserts\">Desserts</a>&nbsp;<a href=\"/Catering\">Catering</a>&nbsp;<a href=\"/wok-smart\">Wok Smart</a>&nbsp;<a href=\"/innovationkitchen\">Innovation Kitchen</a>&nbsp;<a href=\"/teabar\">Tea Bar</a>&nbsp;<a href=\"/pandasfuture\">Taste the Future</a>&nbsp;<a href=\"/masters-of-flavor\">Masters of Flavor</a><a href=\"/wok\">Masters of the Wok</a>&nbsp;<a href=\"https://s3.amazonaws.com/PandaExpressWebsite/files/pdf/Nutrition.pdf\" target=\"_blank\">Download Nutrition PDF</a></div>",
      "Order": 0,
      "Slug": "OurFoodSubMenu"
    },
    {
      "Id": "ad043e4e-e768-475d-b440-c4985c343c40",
      "Content": "<span class=\"legal\">* Ingredient and item selections may vary by location.</span>            <span class=\"legal\">2,000 calories a day is used for general nutrition advice,but calorie needs vary.</span>            <span class=\"legal\">Additional written nutrition information available upon request.</span>            <span class=\"legal\">Variations in nutrition values may occur based upon regional and seasonal ingredient differences, packaging differences and menu items being individually hand served. Panda uses ingredients that contain all the major FDA allergens (peanuts, tree nuts, eggs, fish, shellfish, milk, soy and wheat). Panda prepares its entrees fresh with shared cooking equipment and therefore allergens could be present in any entree. Panda Express does not have any vegetarian or gluten free dishes. No MSG added except for that naturally occurring in certain ingredients.</span>",
      "Order": 0,
      "Slug": "ItemDisclaimer"
    }
  ]
});
    }(window[window.appnamespace] = window[window.appnamespace] || {}));
</script>


    <script src="//cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js"></script>

    <script type="text/javascript">
    (function (acrl, $) {
        window.panda.rooturl = 'http://www.pandaexpress.com/';
    }(window.panda = window.panda || {}, jQuery));

    $('.QapTcha').QapTcha();
    </script>

</body>
</html>
